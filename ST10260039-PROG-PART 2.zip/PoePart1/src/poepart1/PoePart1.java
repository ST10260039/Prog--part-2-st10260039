package poepart1;

import javax.swing.JOptionPane;
import static poepart1.Login.checkUsername;
import static poepart1.Login.validPassword;



public class PoePart1 {
  public String name;

    public String surname;
    
    public static void main(String[] args) {
     
    
     //following code asks user to enter details, checks those details if they are valid, if they are allows user to continue to login and successfully use the application
        JOptionPane.showMessageDialog(null, "You have to register first in order to login");
         JOptionPane.showMessageDialog(null,"To register please enter the following details");
         String name = JOptionPane.showInputDialog(null, "Enter your name: ");
         String surname = JOptionPane.showInputDialog(null, "Enter your last name: ");
         String username= JOptionPane.showInputDialog(null, "Enter your username: ");
         if (checkUsername(username)){
             JOptionPane.showMessageDialog(null,"Username successfully captured");
         } else {
             JOptionPane.showMessageDialog(null,"Format not met! Please contain special characters and atleast 1 Capital letter");
         }
         
         String password= JOptionPane.showInputDialog(null, "Enter your password: ");
         
         if ( validPassword(password)){
             JOptionPane.showMessageDialog(null,"Username & Password  successfully captured");
         } else {
             JOptionPane.showMessageDialog(null,"Format not met! Include atleast 8 characters,a capital letter,a special character and a number ");
             main(null);
         }
         
        
         
         Login poepart1 = new Login (username,password);
         JOptionPane.showMessageDialog(null, "To login eter the following details");
         String username2 = JOptionPane.showInputDialog(null, "Please enter your username: ");
         String Userpassword = JOptionPane.showInputDialog(null, " PLease enter your password: ");
         boolean ReturnLoginStatus = poepart1.LoginUser(username2, Userpassword);
        
         System.out.println(poepart1.ReturnLoginStatus(ReturnLoginStatus));
         
        if (ReturnLoginStatus){
             JOptionPane.showMessageDialog(null,"Welcome back to "+ name + surname);
             JOptionPane.showMessageDialog(null,"Welcome to EasyKanban");
            //method thats called that has all the code for part 2
            poepart1.Part2();
         } else {
             JOptionPane.showMessageDialog(null,"Incorrect password or username");
         }
    }
}




 